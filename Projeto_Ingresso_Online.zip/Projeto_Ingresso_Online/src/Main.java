import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        System.out.println("Cadastro de Pessoa Física:");
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Senha: ");
        String senha = scanner.nextLine();
        System.out.print("CPF: ");
        String cpf = scanner.nextLine();
        System.out.print("Data de Nascimento: ");
        String dataNascimento = scanner.nextLine();

        UsuarioComum usuario = new UsuarioComum(nome, email, senha, cpf, dataNascimento);


        System.out.println("\nCadastro de Promotor:");
        System.out.print("Nome: ");
        nome = scanner.nextLine();
        System.out.print("Email: ");
        email = scanner.nextLine();
        System.out.print("Senha: ");
        senha = scanner.nextLine();
        System.out.print("CNPJ: ");
        String cnpj = scanner.nextLine();

        Promotor promotor = new Promotor(nome, email, senha, cnpj);


        List<Evento> eventos = new ArrayList<>();
        System.out.println("\nCadastro de Eventos:");
        char cadastrarEvento = 's';

        while (cadastrarEvento == 's') {
            System.out.print("Título do Evento: ");
            String titulo = scanner.nextLine();
            System.out.print("Data: ");
            String data = scanner.nextLine();
            System.out.print("Hora: ");
            String hora = scanner.nextLine();
            System.out.print("Local: ");
            String local = scanner.nextLine();

            Evento evento = new Evento(titulo, data, hora, local);
            eventos.add(evento);

            System.out.print("Deseja cadastrar outro evento? (s/n): ");
            cadastrarEvento = scanner.nextLine().charAt(0);
        }


        List<Ingresso> ingressos = new ArrayList<>();
        System.out.println("\nCadastro de Ingressos:");
        for (Evento evento : eventos) {
            System.out.println("Evento: " + evento.getTitulo());
            System.out.print("Quantidade máxima de ingressos: ");
            int qtdeMax = scanner.nextInt();
            scanner.nextLine();

            char cadastrarIngresso = 's';

            while (cadastrarIngresso == 's') {
                System.out.print("Tipo de Ingresso: ");
                String tipoIngresso = scanner.nextLine();
                System.out.print("Valor: ");
                double valor = scanner.nextDouble();
                scanner.nextLine();

                Ingresso ingresso = new Ingresso(evento, valor, qtdeMax, tipoIngresso);
                ingressos.add(ingresso);

                System.out.print("Deseja cadastrar outro ingresso para o mesmo evento? (s/n): ");
                cadastrarIngresso = scanner.nextLine().charAt(0);
            }
        }


        System.out.print("\nQuantidade máxima de ingressos para venda no site: ");
        int qtdeMaxVendaSite = scanner.nextInt();
        scanner.nextLine(); //

        VendaSite vendaSite = new VendaSite(qtdeMaxVendaSite, ingressos);


        System.out.println("\nCadastro de Ingressos para venda no site:");
        char cadastrarVendaSite = 's';

        while (cadastrarVendaSite == 's') {
            if (vendaSite.validaQtdeIngresso()) {
                System.out.print("Evento: ");
                String tituloEvento = scanner.nextLine();
                System.out.print("Tipo de Ingresso: ");
                String tipoIngresso = scanner.nextLine();

                Evento eventoEncontrado = null;
                Ingresso ingressoEncontrado = null;

                for (Evento evento : eventos) {
                    if (evento.getTitulo().equals(tituloEvento)) {
                        eventoEncontrado = evento;
                        break;
                    }
                }

                if (eventoEncontrado != null) {
                    for (Ingresso ingresso : ingressos) {
                        if (ingresso.getEvento() == eventoEncontrado && ingresso.getTipoIngresso().equals(tipoIngresso)) {
                            ingressoEncontrado = ingresso;
                            break;
                        }
                    }

                    if (ingressoEncontrado != null) {
                        vendaSite.getIngresso().add(ingressoEncontrado);
                        System.out.println("Ingresso cadastrado para venda no site.");
                    } else {
                        System.out.println("Ingresso não encontrado.");
                    }
                } else {
                    System.out.println("Evento não encontrado.");
                }
            } else {
                System.out.println("Quantidade máxima de ingressos atingida. Não é possível cadastrar mais ingressos.");
                break;
            }

            System.out.print("Deseja cadastrar outro ingresso para venda no site? (s/n): ");
            cadastrarVendaSite = scanner.nextLine().charAt(0);
        }

        scanner.close();
    }
}
