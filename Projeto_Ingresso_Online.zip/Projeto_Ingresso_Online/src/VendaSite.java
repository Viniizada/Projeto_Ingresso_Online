import java.util.ArrayList;
import java.util.List;

public class VendaSite {
    private int qtdeMax;
    private List<Ingresso> ingresso;

    public VendaSite(int qtdeMax, List<Ingresso> ingresso) {
        this.qtdeMax = qtdeMax;
        this.ingresso = ingresso;
    }

    public int getQtdeMax() {
        return qtdeMax;
    }

    public void setQtdeMax(int qtdeMax) {
        this.qtdeMax = qtdeMax;
    }

    public List<Ingresso> getIngresso() {
        return ingresso;
    }

    public void setIngresso(List<Ingresso> ingresso) {
        this.ingresso = ingresso;
    }
    public void InsereVenda() {
        ingresso = new ArrayList<>();
    }
    public boolean validaQtdeIngresso() {
        return ingresso.size() < qtdeMax;
    }
}

